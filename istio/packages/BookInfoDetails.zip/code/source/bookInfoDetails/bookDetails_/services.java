package bookInfoDetails.bookDetails_;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class services

{
	// ---( internal utility methods )---

	final static services _instance = new services();

	static services _newInstance() { return new services(); }

	static services _cast(Object o) { return (services)o; }

	// ---( server methods )---




	public static final void getVersion (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getVersion)>> ---
		// @sigtype java 3.5
		// [o] field:0:required version
		// [o] field:0:required serviceVersion
		String version = System.getenv("VERSION");
		if ( version != null ) {
			IDataUtil.put(pipeline.getCursor(), "version", version);
		}
		else {
			IDataUtil.put(pipeline.getCursor(), "version", "default");
		}
		
		String serviceVersion = System.getenv("SERVICE_VERSION");
		if ( serviceVersion != null ) {
			IDataUtil.put(pipeline.getCursor(), "serviceVersion", serviceVersion);
		}
		else {
			IDataUtil.put(pipeline.getCursor(), "serviceVersion", "default");
		}
		
			
		// --- <<IS-END>> ---

                
	}



	public static final void sleepService (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(sleepService)>> ---
		// @sigtype java 3.5
		try {
			
			if ( SERVICE_COUNTER % 2 != 0 ) {
				SERVICE_COUNTER++;
				Thread.currentThread().sleep(30000);	
				throw new ServiceException("Service throws error after timeout!");
			}
			else {
				SERVICE_COUNTER++;
			}
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	
	public static int SERVICE_COUNTER = 1;
	// --- <<IS-END-SHARED>> ---
}

