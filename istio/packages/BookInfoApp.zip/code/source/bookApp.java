

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class bookApp

{
	// ---( internal utility methods )---

	final static bookApp _instance = new bookApp();

	static bookApp _newInstance() { return new bookApp(); }

	static bookApp _cast(Object o) { return (bookApp)o; }

	// ---( server methods )---




	public static final void throwError (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(throwError)>> ---
		// @sigtype java 3.5
		// [i] field:0:required message
		String message = IDataUtil.getString(pipeline.getCursor(), "message");
		throw new ServiceException("Exception thrown from the service: " + message);
		// --- <<IS-END>> ---

                
	}
}

